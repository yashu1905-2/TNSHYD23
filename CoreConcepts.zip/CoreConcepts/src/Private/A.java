package Private;

public class A {
	private void display()
	{
	System.out.println("TNS Sessions");
	}
	}



