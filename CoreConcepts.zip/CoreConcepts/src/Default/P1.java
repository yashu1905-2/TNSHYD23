package Default;

class P1 {
	

	void display()
	{
	System.out.println("Hello World!");
	}
}
	


