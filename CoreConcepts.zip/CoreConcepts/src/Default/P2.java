package Default;
//This class is having default access modifier
class p2
{
public static void main(String args[])
{
//accessing class MyClass1 from package p1
P1 obj = new P1();
obj.display();
}
}



