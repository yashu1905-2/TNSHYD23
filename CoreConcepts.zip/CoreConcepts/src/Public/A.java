package Public;

public class A 
	{
	public void display()
	{
	System.out.println("TNS Sessions");
	}
	}


