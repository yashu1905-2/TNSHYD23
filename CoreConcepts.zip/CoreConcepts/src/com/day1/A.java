package com.day1;

public class A {
	
	int a=10;
	static int b=20;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int c=30;
		
		System.out.println(c);
		
		A a1 = new A();
		System.out.println(a1.a);
		
		System.out.println(A.b);
		
		System.out.println(b);

	}

}
