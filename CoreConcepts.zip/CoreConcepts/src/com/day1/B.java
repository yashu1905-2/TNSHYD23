package com.day1;

public class B {
	int a=13;
	int b=34;
	static int c=45;
}
