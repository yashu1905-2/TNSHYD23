package com.day1;

public class B2 {
public static void main(String[] args) {
				B b=new B();
				System.out.println(b.a);
			}

		}
		


