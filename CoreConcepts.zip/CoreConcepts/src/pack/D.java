package pack;

public class D {
	public void msg(){System.out.println("Hello D");}
	}


