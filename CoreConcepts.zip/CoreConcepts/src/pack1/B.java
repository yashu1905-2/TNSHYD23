package pack1;
import pack.*;
class B{  
  public static void main(String args[]){  
   A obj = new A();  
   C obj1 = new C(); 
   D obj2 = new D(); 
   obj.msg();
   obj1.msg();   
   obj2.msg();
  }  
}


