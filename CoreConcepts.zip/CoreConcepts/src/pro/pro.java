package pro;

public class pro {
	protected int a=34;
	protected int b=25;
	
		
	}