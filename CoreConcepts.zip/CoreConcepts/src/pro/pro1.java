package pro;
import pro.*;

public class pro1 extends pro {
	public static void main(String[] args) {
		pro1 a1=new pro1();
	System.out.println(a1.a);
	System.out.println(a1.b);
	}


}
